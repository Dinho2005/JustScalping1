
// scripts.js
document.addEventListener('DOMContentLoaded', () => {
    const buttons = document.querySelectorAll('.buy-now');
    buttons.forEach(button => {
        button.addEventListener('click', () => {
            const product = button.getAttribute('data-product');
            const price = button.getAttribute('data-price');
            alert(`Product: ${product}\nPrice: $${price}`);
            // Implement payment logic here
        });
    });
});
